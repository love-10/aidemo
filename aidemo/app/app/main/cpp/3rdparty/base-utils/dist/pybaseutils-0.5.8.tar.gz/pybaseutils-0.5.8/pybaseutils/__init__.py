# -*-coding: utf-8 -*-
"""
    @Author : panjq
    @E-mail : pan_jinquan@163.com
    @Date   : 2019-05-07 17:40:27
"""

__version__ = '0.5.8'

#include <iostream>
#include <fstream>
#include "opencv2/opencv.hpp"

using namespace std;

#include "debug.h"



